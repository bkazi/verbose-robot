#ifndef TEST_MODEL_CORNEL_BOX_H
#define TEST_MODEL_CORNEL_BOX_H

#include "objects.h"

void LoadTestModel(std::vector<Object *> &scene);

#endif
